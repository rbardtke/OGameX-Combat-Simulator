# OGame Combat Simulator - WebAssembly Edition

A high-performance OGame combat simulator that runs entirely in your browser using WebAssembly. No server required, no installation needed - just open the HTML file and start simulating battles!

## Features

- ⚡ **Blazing Fast**: Rust-powered combat simulation compiled to WebAssembly
- 🔒 **100% Client-Side**: All computation happens in your browser - completely private
- 📡 **Works Offline**: Once loaded, works without internet connection
- 🎨 **User-Friendly Interface**: Simple text-based input for units
- 📊 **Detailed Results**: Round-by-round breakdown of battle statistics
- 🚀 **Cross-Platform**: Works on Windows, Mac, Linux - any modern browser

## What You Need

**To Use**: Just a modern web browser (Chrome, Firefox, Safari, Edge)

**To Build**:
- Rust (latest stable version)
- wasm-pack (for compiling to WebAssembly)

## Quick Start (For Users)

### Option 1: Use Pre-built Version
1. Download the `OGameX-CombatSim` folder containing the built files
2. Open `OGameX-CombatSim/index.html` in your browser
3. Start simulating battles!

### Option 2: Build It Yourself

1. **Install Rust** (if not already installed):
```bash
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh
```

2. **Install wasm-pack**:
```bash
curl https://rustwasm.github.io/wasm-pack/installer/init.sh -sSf | sh
```

3. **Clone/Download this project**:
```bash
cd ~/workspace/OGameX-battleengine-wasm
```

4. **Build the WASM module**:
```bash
wasm-pack build --target web --out-dir OGameX-CombatSim/pkg
```

5. **Open in browser**:
```bash
# Just open OGameX-CombatSim/index.html in your browser
# Or use a local server (optional):
cd OGameX-CombatSim
python3 -m http.server 8080
# Then visit http://localhost:8080
```

## How to Use

### Input Format

Enter units in the text areas using this simple format:
```
Unit Name: Amount
```

**Example Attacker Input**:
```
Light Fighter: 200
Heavy Fighter: 100
Cruiser: 75
Battleship: 50
Battlecruiser: 25
```

**Example Defender Input**:
```
Light Fighter: 150
Rocket Launcher: 500
Light Laser: 300
Heavy Laser: 150
Gauss Cannon: 75
Plasma Turret: 25
```

### Supported Units

**Ships**:
- Small Cargo, Large Cargo
- Light Fighter, Heavy Fighter
- Cruiser, Battleship, Battlecruiser
- Bomber, Destroyer, Deathstar
- Colony Ship, Recycler
- Espionage Probe, Solar Satellite
- Crawler, Reaper, Pathfinder

**Defense**:
- Rocket Launcher, Light Laser, Heavy Laser
- Gauss Cannon, Ion Cannon, Plasma Turret
- Small Shield Dome, Large Shield Dome
- Anti-Ballistic Missiles, Interplanetary Missiles

### Understanding Results

The simulator shows:
- **Round-by-round breakdown**: See what happens in each of the 6 rounds
- **Remaining units**: What survives after each round
- **Losses per round**: What was destroyed in that round
- **Winner**: Who won the battle (or if it was a draw)

## Combat Mechanics

This simulator implements the complete OGame combat system:

1. **Damage System**: Damage applies to shields first, then hull
2. **Shield Regeneration**: Shields fully regenerate between rounds
3. **Explosion Chance**: Units with <70% hull can explode randomly
4. **Rapidfire**: Some units can shoot multiple times per round
5. **6 Round Limit**: Battles end after 6 rounds maximum

## Project Structure

```
OGameX-battleengine-wasm/
├── src/
│   └── lib.rs              # Rust combat engine source
├── OGameX-CombatSim/
│   ├── index.html          # Web interface
│   ├── style.css           # Styling
│   ├── app.js              # JavaScript logic
│   └── pkg/                # Built WASM files (after build)
├── Cargo.toml              # Rust dependencies
└── README.md               # This file
```

## Building for Production

To create an optimized build:

```bash
wasm-pack build --target web --out-dir OGameX-CombatSim/pkg --release
```

This will create highly optimized WASM binaries for maximum performance.

## Development

### Testing Your Changes

1. Make changes to `src/lib.rs`
2. Rebuild: `wasm-pack build --target web --out-dir OGameX-CombatSim/pkg`
3. Refresh your browser (hard refresh: Ctrl+F5 or Cmd+Shift+R)

### Adding New Features

The combat engine is in `src/lib.rs`. The main entry point is the `simulate_battle()` function which:
1. Takes JSON input with attacker and defender units
2. Runs the combat simulation
3. Returns JSON output with round-by-round results

To modify the UI, edit:
- `OGameX-CombatSim/index.html` - Structure
- `OGameX-CombatSim/style.css` - Appearance
- `OGameX-CombatSim/app.js` - Behavior and unit definitions

## Performance

This combat simulator is approximately **200x faster** than equivalent PHP implementations and can handle:
- Thousands of units in milliseconds
- Complex battles with rapidfire calculations
- Multiple simulations per second

## Based On

This project is a standalone WASM port of the [OGameX](https://github.com/fwatermann/OGameX) battle engine, which is a modern reimplementation of the classic OGame browser game.

## License

This project uses the same license as the original OGameX project.

## Troubleshooting

### "WASM module not loaded yet"
- Wait a few seconds after page load
- Check browser console for errors
- Make sure `OGameX-CombatSim/pkg/` folder exists and contains the WASM files

### "Failed to initialize combat simulator"
- Rebuild the WASM module: `wasm-pack build --target web --out-dir OGameX-CombatSim/pkg`
- Check that you're using a modern browser (Chrome 57+, Firefox 52+, Safari 11+, Edge 16+)

### Units not recognized
- Check spelling and capitalization (e.g., "Light Fighter" not "light fighter")
- Make sure format is: `Unit Name: Amount`
- One unit per line

### Battle results look wrong
- This simulator implements official OGame mechanics
- RNG (randomness) means results vary between runs
- Try running the same battle multiple times to see average outcomes

## Contributing

Found a bug? Want to add features? Contributions are welcome! This is a standalone project, so feel free to modify it for your needs.

---

**Enjoy simulating epic space battles! 🚀⚔️🛡️**
